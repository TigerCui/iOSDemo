//
//  ViewController.m
//  YourApp
//
//  Created by 崔正清 on 16/3/25.
//  Copyright © 2016年 cuizhengqing. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (IBAction)goBackMyApp:(id)sender {
    UIApplication *app = [UIApplication sharedApplication];
    NSURL *url = [NSURL URLWithString:@"my://"];
    if ([app canOpenURL:url]) {
        [app openURL:url];
    }else{
        NSLog(@"跳回到myapp失败");
    }
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
