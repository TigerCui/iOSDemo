//
//  ViewController.m
//  MyApp
//
//  Created by 崔正清 on 16/3/25.
//  Copyright © 2016年 cuizhengqing. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (IBAction)gotoYoueApp:(UIButton *)sender {
    // 1.获取application对象
    UIApplication *app = [UIApplication sharedApplication];
    
    // 2.创建要打开的应用程序的URL
    NSURL *url = [NSURL URLWithString:@"your://aaa"];
    
    // 3.判断是否可以打开另一个应用
    if ([app canOpenURL:url]) {
        // 能，就打开
        [app openURL:url];
    }else{
        NSLog(@"打开应用失败");
    }
}

- (IBAction)gotoYourAppSecond:(UIButton *)sender {
    // 1.获取application对象
    UIApplication *app = [UIApplication sharedApplication];
    
    // 2.创建要打开的应用程序的URL
    NSURL *url = [NSURL URLWithString:@"your://bbb"];
    
    // 3.判断是否可以打开另一个应用
    if ([app canOpenURL:url]) {
        // 能，就打开
        [app openURL:url];
    }else{
        NSLog(@"打开应用失败");
    }
}

@end
